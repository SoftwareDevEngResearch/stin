γ = 1.3
C_0 = 1.1
v_s = 0.2
a = 500
ρ_L = 1000
g = 9.81
f = 0.03
D = 0.002 # m^2 - for 1" (2.5cm) annulus but without annulus
